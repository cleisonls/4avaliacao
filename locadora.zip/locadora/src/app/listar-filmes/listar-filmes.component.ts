import { Component, OnInit } from '@angular/core';
import { Filmes } from '../filmes';
import { FilmesService } from '../filmes.service';

@Component({
  selector: 'app-listar-filmes',
  templateUrl: './listar-filmes.component.html',
  styleUrls: ['./listar-filmes.component.css']
})
export class ListarFilmesComponent implements OnInit {
  filme : Filmes = {
    id: 0,
    titulo: '',
    genero: '',
    idioma: '',
    ano: ''
  }

  constructor(private FilmesService: FilmesService) {
    this.filme.id = this.FilmesService.getNextId();
  } 

  ngOnInit() {
  }

  filmes = this.FilmesService.getAll()

  onAdd(): void {
    this.FilmesService.add(this.filme)
    this.limpar()
  }

  limpar(): void {
    this.filme = new Filmes();
    let number = this.FilmesService.getNextId()
    this.filme.id = number;
  }
  
  removerFilme(id){
    this.FilmesService.removerFilme(id)
    this.filmes = this.FilmesService.getAll()
  }

}