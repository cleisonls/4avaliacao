import { Component, OnInit } from '@angular/core';
import { FILMES } from '../mock-filmes';
import { Filmes } from '../filmes';
import { FilmesService } from '../filmes.service';

@Component({
  selector: 'app-listar-filmes',
  templateUrl: './listar-filmes.component.html',
  styleUrls: ['./listar-filmes.component.css']
})
export class ListarFilmesComponent implements OnInit {

  filmes = FILMES

  filme : Filmes = {
    id: 1,
    titulo: '',
    genero: '',
    idioma: '',
    ano: ''
  }

  constructor() { }

  ngOnInit() {
  }

  onAdd(): void {
    this.filmes.push(this.filme)
    this.filme.id++
    this.limpar(this.filme.id)
  }

  limpar(number: number): void{
    this.filme.titulo = ''
    this.filme.genero = ''
    this.filme.idioma = ''
    this.filme.ano = ''
  }

}
