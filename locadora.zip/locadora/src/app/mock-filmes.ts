import { Filmes } from "./filmes";
export const FILMES: Filmes[] = [
    {
        id: 1,
        titulo: 'Titanic',
        genero: 'Ação',
        idioma: 'Inglês',
        ano: '1997'
    },
    {
        id: 2,
        titulo: 'Vingadores',
        genero: 'Ação',
        idioma: 'Inglês',
        ano: '2018'
    }
]