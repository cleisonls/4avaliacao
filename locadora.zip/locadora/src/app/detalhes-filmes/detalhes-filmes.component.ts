import { Component, OnInit } from '@angular/core';
import { Filmes } from '../filmes';
import { ActivatedRoute } from '@angular/router';
import { FILMES } from '../mock-filmes';
import { FilmesService } from '../filmes.service';

@Component({
  selector: 'app-detalhes',
  templateUrl: './detalhes-filmes.component.html',
  styleUrls: ['./detalhes-filmes.component.css']
})
export class DetalhesFilmesComponent implements OnInit {

  filme = new Filmes()
  idfilme: any 
  filmes: any

  constructor(private route: ActivatedRoute, private FilmesService: FilmesService) {
    this.idfilme = this.route.snapshot.params['idfilme'];
    this.filmes = FILMES
    var filme = this.FilmesService.getById(this.idfilme);

    if(filme !== undefined){
      this.filme = filme
    }
  }

  ngOnInit() {
  }

  getGetParams() {
    return this.route.snapshot.queryParams;
  }
  
}

