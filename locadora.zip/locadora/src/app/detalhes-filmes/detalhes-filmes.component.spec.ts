import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalhesFilmesComponent } from './detalhes-filmes.component';

describe('DetalhesFilmesComponent', () => {
  let component: DetalhesFilmesComponent;
  let fixture: ComponentFixture<DetalhesFilmesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalhesFilmesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalhesFilmesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
