import { Component, OnInit } from '@angular/core';
import { FILMES } from '../mock-filmes';
import { FilmesService } from '../filmes.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  lfilmes = FILMES;
  qtdFilmes() {
    return this.FilmesService.getQtd()
  }

  constructor(private FilmesService:FilmesService) { }

  ngOnInit() {
  }

}
